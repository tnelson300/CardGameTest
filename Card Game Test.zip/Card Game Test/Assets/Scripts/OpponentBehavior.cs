﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Controls the opponents hand, handling card management
/// </summary>
public class OpponentBehavior : MonoBehaviour {

    static OpponentBehavior _instance;
    [SerializeField] int maxAttack, minAttack, maxHealth, minHealth;
    [SerializeField] GameObject cardPrefab, tempCard;
    Card[] deck;
    int playedCount = 0;
    public static OpponentBehavior Instance
    {
        get
        {
            return _instance;
        }
    }

    void Start()
    {
        _instance = this;
        deck = new Card[13];
        for (int i = 0; i < deck.Length; i++)
        {
            deck[i] = new Card(Random.Range(minHealth, maxHealth), Random.Range(minAttack, maxAttack));
        }

        for (int i = 0; i < 3; i++)
        {
            GameObject newGO = Instantiate(cardPrefab);
            newGO.transform.SetParent(transform);
            newGO.transform.SetAsLastSibling();
            newGO.transform.localScale = Vector3.one;
        }
    }
    public void PlayCard()
    {
        TableController.Instance.AddOpponentCard(deck[playedCount]);
        playedCount++;
        Destroy(transform.GetChild(0).gameObject);
        TurnOrderController.NextState();
    }
    public void DrawCard()
    {
        StartCoroutine("Drawing");
    }
    IEnumerator Drawing()
    {
        yield return new WaitForSeconds(0.5f);
        TableController.Instance.CheckForNeedLine();
        yield return new WaitForSeconds(0.5f);
        GameObject newGO = Instantiate(cardPrefab);
        newGO.transform.SetParent(transform);
        newGO.transform.SetAsLastSibling();
        newGO.transform.localScale = Vector3.one;
        newGO.transform.GetChild(0).gameObject.SetActive(false);
        yield return null;

        float moveTime = 0, moveSpeed = 0.03f;
        Vector3 starting = tempCard.transform.position;
        tempCard.SetActive(true);
        while (moveTime < 1)
        {
            tempCard.transform.position = Vector3.Lerp(starting, newGO.transform.position, moveTime);
            moveTime += moveSpeed;
            yield return null;
        }
        tempCard.SetActive(false);
        newGO.transform.GetChild(0).gameObject.SetActive(true);
        tempCard.transform.position = starting;
        yield return new WaitForSeconds(1);
        TurnOrderController.NextState();
    }
    public void Clear()
    {
        List<GameObject> childs = new List<GameObject>();
        foreach (Transform tt in transform)
            childs.Add(tt.gameObject);
        childs.ForEach(child => Destroy(child));
        Start();
    }
}
