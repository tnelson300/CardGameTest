﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Controls the players hand and deck and in charge of the transfer between the two
/// </summary>
public class Player : MonoBehaviour {

    [SerializeField] int maxAttack, minAttack, maxHealth, minHealth;
    [SerializeField] GameObject cardPrefab, dragCard, tempCard;
    Card[] deck;
    int orderInDeck = 3;

	void Start () 
    {
        TurnOrderController.Initialize(this);
        TableController.Instance.AddBattleLine();
        orderInDeck = 3;
        deck = new Card[13];
        for (int i = 0; i < deck.Length; i++)
        {
            deck[i] = new Card(Random.Range(minHealth, maxHealth), Random.Range(minAttack, maxAttack));
        }

        for (int i = 0; i < 3; i++)
        {
            GameObject newGO = Instantiate(cardPrefab);
            newGO.transform.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text = "A " + deck[i].Attack.ToString();
            newGO.transform.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = "H " + deck[i].Health.ToString();
            newGO.transform.SetParent(transform);
            newGO.transform.SetAsLastSibling();
            newGO.transform.localScale = Vector3.one;
            newGO.GetComponent<DragNDrop>().Values = deck[i];
        }
	}
    public void DrawCard()
    {
        StartCoroutine("Drawing");
    }
    IEnumerator Drawing()
    {
        GameObject newGO = Instantiate(cardPrefab);
        newGO.transform.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text = "A " + deck[orderInDeck].Attack.ToString();
        newGO.transform.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = "H " + deck[orderInDeck].Health.ToString();
        tempCard.transform.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text = "A " + deck[orderInDeck].Attack.ToString();
        tempCard.transform.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = "H " + deck[orderInDeck].Health.ToString();
        newGO.transform.SetParent(transform);
        newGO.transform.SetAsLastSibling();
        newGO.transform.localScale = Vector3.one;
        newGO.GetComponent<DragNDrop>().Values = deck[orderInDeck];
        newGO.transform.GetChild(0).gameObject.SetActive(false);
        orderInDeck++;
        yield return null;

        float moveTime = 0, moveSpeed = 0.02f;
        Vector3 starting = tempCard.transform.position;
        tempCard.transform.localScale = new Vector3(-1, 1, 1);
        tempCard.transform.GetChild(0).FindChild("Attack Text").gameObject.SetActive(false);
        tempCard.transform.GetChild(0).FindChild("Health Text").gameObject.SetActive(false);
        tempCard.SetActive(true);
        bool switchScale = true;
        while (moveTime < 1)
        {
            tempCard.transform.position = Vector3.Lerp(starting, newGO.transform.position, moveTime);
            tempCard.transform.localScale = new Vector3(Mathf.Lerp(-1, 1, moveTime), 1, 1);
            if (tempCard.transform.localScale.x >= 0 && switchScale)
            {
                tempCard.transform.GetChild(0).FindChild("Attack Text").gameObject.SetActive(true);
                tempCard.transform.GetChild(0).FindChild("Health Text").gameObject.SetActive(true);
                switchScale = false;
            }
            moveTime += moveSpeed;
            yield return null;
        }
        tempCard.SetActive(false);
        newGO.transform.GetChild(0).gameObject.SetActive(true);
        tempCard.transform.position = starting;
        yield return new WaitForSeconds(0.4f);
        TurnOrderController.NextState();
    }
    public void Clear()
    {
        List<GameObject> childs = new List<GameObject>();
        foreach (Transform tt in transform)
            childs.Add(tt.gameObject);
        childs.ForEach(child => Destroy(child));
        Start();
    }
}

/// <summary>
/// Basic info for any card in the game
/// </summary>
public struct Card
{
    int health, attack;

    public int Health
    {
        get
        {
            return health;
        }
    }
    public int Attack
    {
        get
        {
            return attack;
        }
    }

    public Card(int _health, int _attack)
    {
        health = _health;
        attack = _attack;
    }
}