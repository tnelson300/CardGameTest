﻿using UnityEngine;
using System.Collections;

/// <summary>
/// State machine for handling turn action order
/// All actions by the player and opponent go through this class to start and end a turn action
/// </summary>
public static class TurnOrderController {

    public enum TurnState { PlayerDraw, PlayerTurn, PlayerCardAttack, OpponentDraw, OpponentTurn, OpponentCardAttack}
    static TurnState _currentState;
    static Player _player;

    public static void Initialize(Player pp)
    {
        _currentState = TurnState.PlayerTurn;
        _player = pp;
    }

    public static void NextState()
    {
        switch (_currentState)
        {
            case TurnState.PlayerTurn:
                _currentState = TurnState.PlayerCardAttack;
                break;
            case TurnState.PlayerCardAttack:
                if (TableController.Instance.CheckReset())
                {
                    OpponentBehavior.Instance.Clear();
                    _player.Clear();
                    return;
                }
                _currentState = TurnState.OpponentDraw;
                OpponentBehavior.Instance.DrawCard();
                break;
            case TurnState.OpponentDraw:
                _currentState = TurnState.OpponentTurn;
                OpponentBehavior.Instance.PlayCard();
                break;
            case TurnState.OpponentTurn:
                _currentState = TurnState.OpponentCardAttack;
                TableController.Instance.EndOpponentTurn();
                break;
            case TurnState.OpponentCardAttack:
                if (TableController.Instance.CheckReset())
                {
                    OpponentBehavior.Instance.Clear();
                    _player.Clear();
                    return;
                }
                _currentState = TurnState.PlayerDraw;
                _player.DrawCard();
                break;
            case TurnState.PlayerDraw:
                _currentState = TurnState.PlayerTurn;
                TableController.Instance.StartPlayerTurn();
                break;
        }
    }
}
