﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

/// <summary>
/// This class is attached to the object that follows the mouse input.
/// Reads cards when dragging begins and handles actions for when the card is dropped
/// </summary>
public class DragCard : MonoBehaviour {

    Vector3 offset, startingDragPos, targetDragPos;
    bool isDragging;
    Transform visualsRef;
    GameObject emptySlot;
    static DragCard _instance;
    public static DragCard Instance
    {
        get
        {
            return _instance;
        }
    }

    void Awake()
    {
        _instance = this;
        isDragging = false;
    }

	void Update () {
        transform.position = Input.mousePosition - offset;
	}
    public void BeginDrag(Vector3 startingPos, Transform visuals)
    {
        isDragging = true;
        targetDragPos = startingPos;
        transform.position = startingPos;
        offset = Input.mousePosition - transform.position;
        transform.GetChild(0).gameObject.SetActive(true);
        transform.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text = visuals.FindChild("Attack Text").GetComponent<Text>().text;
        transform.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = visuals.FindChild("Health Text").GetComponent<Text>().text;
    }
    public void EndDrag(Transform draggedRef)
    {
        startingDragPos = transform.position;
        visualsRef = draggedRef;
        if (emptySlot != null)
        {
            visualsRef = emptySlot.transform.parent;
            visualsRef.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text = transform.GetChild(0).FindChild("Attack Text").GetComponent<Text>().text;
            visualsRef.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = transform.GetChild(0).FindChild("Health Text").GetComponent<Text>().text;
            targetDragPos = emptySlot.transform.position;
            TableController.Instance.AddPlayerCard(visualsRef.parent.gameObject, draggedRef.GetComponent<DragNDrop>().Values);
            emptySlot.SetActive(false);
            Destroy(draggedRef.gameObject);
        }
        StartCoroutine("SlideToPos");
    }

    IEnumerator SlideToPos()
    {
        float slideTime = 0;
        bool shouldEnd = emptySlot != null;
        while (slideTime < 1)
        {
            slideTime += 0.1f;
            transform.position = Vector3.Lerp(startingDragPos, targetDragPos, slideTime);
            yield return null;
        }
        transform.GetChild(0).gameObject.SetActive(false);
        visualsRef.GetChild(0).gameObject.SetActive(true);
        if (shouldEnd)
        {
            TableController.Instance.EndPlayerTurn();
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Slot")
        {
            emptySlot = coll.gameObject;
        }
    }
    void OnTriggerExit2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Slot")
        {
            if (emptySlot == coll.gameObject)
                emptySlot = null;
        }
    }
}
