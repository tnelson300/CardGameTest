﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// Controller for the middle of the table
/// Handles all actions for cards that have been played along with healths
/// </summary>
public class TableController : MonoBehaviour {

    [SerializeField] GameObject linePrefab;
    [SerializeField] Player playerCharacter;
    [SerializeField] OpponentBehavior opponentCharacter;
    [SerializeField] Text playerHP, opponentHP;
    static TableController _instance;
    List<GameObject> allBattleLines;
    Dictionary<GameObject, int> playerAttacks, playerHealths, enemyAttacks, enemyHealths;
    int opponentHealth, health;
    bool isPlayersTurn;

    public bool IsPlayersTurn
    {
        get
        {
            return isPlayersTurn;
        }
    }

    public static TableController Instance
    {
        get
        {
            return _instance;
        }
    }
    void Start()
    {
        _instance = this;
        allBattleLines = new List<GameObject>();
        playerAttacks = new Dictionary<GameObject, int>();
        playerHealths = new Dictionary<GameObject, int>();
        enemyAttacks = new Dictionary<GameObject, int>();
        enemyHealths = new Dictionary<GameObject, int>();
        opponentHealth = 10;
        health = 10;
        UpdateHealthText(); 
        isPlayersTurn = true;
    }

    public GameObject AddBattleLine()
    {
        GameObject newGo = Instantiate(linePrefab);
        //create new battleline;
        allBattleLines.Add(newGo);
        newGo.transform.SetParent(transform);
        newGo.transform.SetAsLastSibling();
        newGo.transform.localScale = Vector3.one;
        playerAttacks.Add(newGo, 0);
        playerHealths.Add(newGo, 0);
        enemyAttacks.Add(newGo, 0);
        enemyHealths.Add(newGo, 0);
        return newGo;
    }
    public void StartPlayerTurn()
    {
        isPlayersTurn = true;
    }
    public void EndPlayerTurn()
    {
        isPlayersTurn = false;
        TurnOrderController.NextState();
        StartCoroutine("PlayerAttacks");
    }
    public void EndOpponentTurn()
    {
        StartCoroutine("OpponentAttacks");
    }
    int DamageCard(Transform cardObject, int attackAmount, int cardHealth)
    {
        if (cardHealth - attackAmount > 0)
        {
            cardObject.GetChild(0).FindChild("Health Text").GetComponent<Text>().text = "H " + (cardHealth - attackAmount).ToString();
        }
        else
        {
            cardObject.GetChild(0).gameObject.SetActive(false);
            if (cardObject.childCount > 1)
            {
                cardObject.FindChild("Empty Slot").gameObject.SetActive(true);
            }
        }
        return cardHealth - attackAmount;
    }
    /// <summary>
    /// Adds the values to the line dicts
    /// </summary>
    /// <param name="battleLine">Line this card is filling</param>
    /// <param name="toAdd">Card to add</param>
    public void AddPlayerCard(GameObject battleLine, Card toAdd)
    {
        playerAttacks[battleLine] = toAdd.Attack;
        playerHealths[battleLine] = toAdd.Health;
    }
    /// <summary>
    /// Finds the first lane without a card and adds one to it, updating the visuals.
    /// If there are no open lanes, create a new one
    /// </summary>
    /// <param name="toAdd">Card to add</param>
    public void AddOpponentCard(Card toAdd)
    {
        bool addNew = true;
        foreach (GameObject battleLine in enemyHealths.Keys)
        {
            if (enemyHealths[battleLine] <= 0)
            {
                enemyAttacks[battleLine] = toAdd.Attack;
                enemyHealths[battleLine] = toAdd.Health;
                GameObject visual = battleLine.transform.FindChild("Top Card").GetChild(0).gameObject;
                visual.SetActive(true);
                visual.transform.FindChild("Health Text").GetComponent<Text>().text = "H " + toAdd.Health.ToString();
                visual.transform.FindChild("Attack Text").GetComponent<Text>().text = "A " + toAdd.Attack.ToString();
                addNew = false;
                break;
            }
        }
        if (addNew)
        {
            GameObject temp = AddBattleLine();
            enemyAttacks[temp] = toAdd.Attack;
            enemyHealths[temp] = toAdd.Health;
        }
    }
    /// <summary>
    /// Ittirates through all lanes and creates a new one if all player slots are filled with cards
    /// </summary>
    public void CheckForNeedLine()
    {
        bool shouldCreate = true;
        foreach (GameObject battleLine in allBattleLines)
        {
            if (playerHealths[battleLine] <= 0 && enemyHealths[battleLine] <= 0)
            {
                shouldCreate = false;
                break;
            }
        }
        if (shouldCreate)
            AddBattleLine();
    }

    IEnumerator PlayerAttacks()
    {
        Vector3 topCard, bottomCard;
        float moveTime = 0.01f, moveSpeed = 0.1f;
        Transform cardMoving;

        foreach (GameObject battleLine in playerAttacks.Keys)
        {
            if (playerHealths[battleLine] <= 0)
                continue;

            if (enemyHealths[battleLine] > 0)
            {
                topCard = battleLine.transform.FindChild("Top Card").position;
                cardMoving = battleLine.transform.FindChild("Bottom Card");
                bottomCard = cardMoving.position;
                while (moveTime > 0)
                {
                    moveTime += moveSpeed;
                    cardMoving.position = Vector3.Lerp(bottomCard, topCard, moveTime);
                    if (moveTime >= 1)
                    {
                        enemyHealths[battleLine] = DamageCard(battleLine.transform.GetChild(0), playerAttacks[battleLine], enemyHealths[battleLine]);
                        moveSpeed *= -1;
                    }
                    yield return null;
                }
                cardMoving.position = bottomCard;
            }
            else
            {
                if (opponentHealth > 0)
                {
                    topCard = opponentHP.transform.position;
                    cardMoving = battleLine.transform.FindChild("Bottom Card");
                    bottomCard = cardMoving.position;
                    while (moveTime > 0)
                    {
                        moveTime += moveSpeed;
                        cardMoving.position = Vector3.Lerp(bottomCard, topCard, moveTime);
                        if (moveTime >= 1)
                        {
                            opponentHealth -= playerAttacks[battleLine];
                            UpdateHealthText();
                            moveSpeed *= -1;
                        }
                        yield return null;
                    }
                    cardMoving.position = bottomCard;
                }
            }
            moveTime = 0.01f;
            moveSpeed *= -1;
            yield return new WaitForSeconds(0.5f);
        }
        TurnOrderController.NextState();
    }
    IEnumerator OpponentAttacks()
    {
        yield return new WaitForSeconds(1);
        Vector3 topCard, bottomCard;
        float moveTime = 0.01f, moveSpeed = 0.1f;
        Transform cardMoving;

        foreach (GameObject battleLine in enemyAttacks.Keys)
        {
            if (enemyHealths[battleLine] <= 0)
                continue;

            if (playerHealths[battleLine] > 0)
            {
                topCard = battleLine.transform.FindChild("Bottom Card").position;
                cardMoving = battleLine.transform.FindChild("Top Card");
                cardMoving.SetAsLastSibling();
                bottomCard = cardMoving.position;
                while (moveTime > 0)
                {
                    moveTime += moveSpeed;
                    cardMoving.position = Vector3.Lerp(bottomCard, topCard, moveTime);
                    if (moveTime >= 1)
                    {
                        playerHealths[battleLine] = DamageCard(battleLine.transform.GetChild(0), enemyAttacks[battleLine], playerHealths[battleLine]);
                        moveSpeed *= -1;
                    }
                    yield return null;
                }
                cardMoving.position = bottomCard;
            }
            else
            {
                cardMoving = battleLine.transform.FindChild("Top Card");
                if (health > 0)
                {
                    topCard = playerHP.transform.position;
                    cardMoving.SetAsLastSibling();
                    bottomCard = cardMoving.position;
                    while (moveTime > 0)
                    {
                        moveTime += moveSpeed;
                        cardMoving.position = Vector3.Lerp(bottomCard, topCard, moveTime);
                        if (moveTime >= 1)
                        {
                            health -= enemyAttacks[battleLine];
                            UpdateHealthText();
                            moveSpeed *= -1;
                        }
                        yield return null;
                    }
                    cardMoving.position = bottomCard;
                }
            }
            cardMoving.SetAsFirstSibling();
            moveTime = 0.01f;
            moveSpeed *= -1;
            yield return new WaitForSeconds(0.5f);
        }
        yield return new WaitForSeconds(1);
        TurnOrderController.NextState();
    }
    void UpdateHealthText()
    {
        if (health >= 0)
            playerHP.text = health.ToString();
        else
            playerHP.text = "0";
        if (opponentHealth >= 0)
            opponentHP.text = opponentHealth.ToString();
        else
            opponentHP.text = "0";
    }
    public bool CheckReset()
    {
        if (health <= 0 || opponentHealth <= 0)
        {
            Clear();
            return true;
        }
        else return false;
    }
    void Clear()
    {
        MainMenuController.Instance.Play(true);
        List<GameObject> childs = new List<GameObject>();
        foreach (Transform tt in transform)
            childs.Add(tt.gameObject);
        childs.ForEach(child => Destroy(child));
        Start();
    }
}
