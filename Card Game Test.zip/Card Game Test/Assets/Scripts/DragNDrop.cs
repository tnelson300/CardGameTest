﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Player hand card, contains values for a card in hand and actions for dragging n dropping player card
/// </summary>
public class DragNDrop : MonoBehaviour {

    Vector3 offset, startingDragPos, targetDragPos;
    Card values;

    public Card Values
    {
        get
        {
            return values;
        }
        set
        {
            values = value;
        }
    }
    public void DroppedIt()
    {
        if (TableController.Instance.IsPlayersTurn)
        {
            DragCard.Instance.EndDrag(transform);
        }
    }
    public void StartDrag()
    {
        if (TableController.Instance.IsPlayersTurn)
        {
            DragCard.Instance.BeginDrag(transform.position, transform.GetChild(0));
            transform.GetChild(0).gameObject.SetActive(false);
        }
    }
}
