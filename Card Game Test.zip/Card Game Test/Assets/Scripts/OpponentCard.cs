﻿using UnityEngine;
using System.Collections;

/// <summary>
/// This class holds all info needed for a card held in the opponents hand
/// </summary>
public class OpponentCard : MonoBehaviour {

    Card values;

    public Card Values
    {
        get
        {
            return values;
        }
        set
        {
            values = value;
        }
    }
}
