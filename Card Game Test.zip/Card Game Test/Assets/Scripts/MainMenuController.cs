﻿using UnityEngine;
using UnityEditor;
using System.Collections;

/// <summary>
/// Menu controller for switching windows
/// </summary>
public class MainMenuController : MonoBehaviour {

    [SerializeField] GameObject menuCanvas;
    static MainMenuController _instance;
    public static MainMenuController Instance
    {
        get
        {
            return _instance;
        }
    }
    void Start()
    {
        _instance = this;
    }

    public void Play(bool comingFromGameplay)
    {
        menuCanvas.SetActive(comingFromGameplay);
    }
    public void Exit()
    {
        EditorApplication.isPlaying = false;
    }
}
